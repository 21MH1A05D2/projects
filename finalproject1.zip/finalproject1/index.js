const express=require('express');
const mongoose=require('mongoose');
const fs=require('fs');
const session=require('express-session');
const pug=require('pug')
const bcrypt=require('bcrypt');
const fileupload=require('express-fileupload');
const app=express();
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded());
app.use(fileupload())
app.set('view engine','pug')
app.use(session({
    secret:'meanstack',
    saveUninitialized:false,
}))
app.listen(3003,(req,res)=>{
    console.log("server is running successfully");
})
let b=mongoose.connect('mongodb://127.0.0.1:27017/finalproject');
b.then((info)=>{
    console.log("Connection Success");
})
b.catch((info)=>{
    console.log("Connection Failed");
})
let cseschema1=new mongoose.Schema({
    user:String,
    pass: {
        type: String,
        required: true
    },
    skey:String
})
let cseschema = new mongoose.Schema({
    recipe: String,
    ingredients: String,
    description: String,
    category: String,
    recipetype:String 
});
let modelcse= new mongoose.model('csedata',cseschema1,'logindata');
let VegRecipe = mongoose.model('VegRecipe', cseschema, 'veg');
let NonVegRecipe = mongoose.model('NonVegRecipe', cseschema, 'nonveg');
app.use((req,res,next)=>{

    res.set('Cache-Control','no-store');
    next();
})
app.get('/home', (req, res) => {
    res.sendFile(__dirname + '/public/home.html');
});

app.get('/viewrecipe', (req, res) => {
    res.sendFile(__dirname + '/public/viewrecipe.html');
});

app.get('/veg', (req, res) => {
    res.sendFile(__dirname + '/public/veg.html');
});
app.get('/vegsnacks', async (req, res, next) => {
    try {
        const vegSnacks = await VegRecipe.find({ category: 'veg', recipetype: 'snack' });
        res.render('vegsnacks', { vegSnacks });
    } catch (error) {
        next(error);
    }
});
app.get('/details', async (req, res) => {
    try {
        const recipeName = req.query.recipe;
        const vegSnack = await VegRecipe.findOne({ recipe: recipeName });

        if (!vegSnack) {
            return res.status(404).send('Recipe not found');
        }

        res.render('details', { vegSnack });
    } catch (error) {
        console.error('Error retrieving recipe details:', error);
        res.status(500).send('Error retrieving recipe details');
    }
});
 

app.get('/veglunchbox', async (req, res, next) => {
    try {
        const vegLunchbox = await VegRecipe.find({ category: 'veg', recipetype: 'lunchbox' });
        res.render('veglunchbox', { vegLunchbox });
    } catch (error) {
        next(error);
    }
});
app.get('/details1', async (req, res) => {
    try {
        const recipe1 = req.query.r;
        const veglunchbox = await VegRecipe.findOne({ recipe: recipe1 });

        if (!veglunchbox) {
            return res.status(404).send('Recipe not found');
        }

        res.render('details1', { veglunchbox });
    } catch (error) {
        console.error('Error retrieving recipe details:', error);
        res.status(500).send('Error retrieving recipe details');
    }
});

app.get('/nonveg', (req, res) => {
    res.sendFile(__dirname + '/public/nonveg.html');
});

app.get('/nonsnacks', async (req, res, next) => {
    try {
        const nonSnacks = await NonVegRecipe.find({ category: 'nonveg', recipetype: 'snack' });
        res.render('nonsnacks', { nonSnacks });
    } catch (error) {
        next(error);
    }
});
app.get('/details2', async (req, res) => {
    try {
        const r = req.query.s;
        const nonSnack = await NonVegRecipe.findOne({ recipe: r });

        if (!nonSnack) {
            return res.status(404).send('Recipe not found');
        }

        res.render('details2', { nonSnack });
    } catch (error) {
        console.error('Error retrieving recipe details:', error);
        res.status(500).send('Error retrieving recipe details');
    }
});

app.get('/nonlunchbox', async (req, res, next) => {
    try {
        const nonLunchbox = await NonVegRecipe.find({ category: 'nonveg', recipetype: 'lunchbox' });
        res.render('nonlunchbox', { nonLunchbox });
    } catch (error) {
        next(error);
    }
});
app.get('/details3', async (req, res) => {
    try {
        const recipe2 = req.query.p;
        const nonlunchbox = await NonVegRecipe.findOne({ recipe: recipe2 });

        if (!nonlunchbox) {
            return res.status(404).send('Recipe not found');
        }

        res.render('details3', { nonlunchbox });
    } catch (error) {
        console.error('Error retrieving recipe details:', error);
        res.status(500).send('Error retrieving recipe details');
    }
});
app.post('/register', async (req, res) => {
    var data={
        user:req.body.reg1,
        pass:req.body.reg2,
        skey:req.body.reg3
    };
    const { user, pass,skey } = data;
    const hashedpassword = await bcrypt.hash(pass,10);
     const newuser = new modelcse({
            user,
            pass: hashedpassword,
            skey,
        });
        await newuser.save();
        res.sendFile(__dirname + '/public/login.html');
    } );
app.post('/login', async (req, res) => {
        var data1={
            user:req.body.lname,
            pass:req.body.pname
        } 
       const { user, pass } = data1;
            const user1 = await modelcse.findOne({user});
            if (!user1) {
                return res.status(400).send("No user found");
            }
            const passwordMatch = await bcrypt.compare(pass, user1.pass);
            if (passwordMatch) {
                return res.sendFile(__dirname + '/public/updaterecipe.html');
            } else {
                return res.sendFile(__dirname + '/public/login.html');
            }
 });
app.post('/forgot', async (req, res) => {
    const { user1, fskey } = req.body;
    try {
        const user = await modelcse.findOne({ user: user1 });
        if (!user) {
            return res.send("User not found");
        }
        if (fskey === user.skey) {
            res.redirect(`/password.html?username=${user.user}`);
        } else {
            return res.send("Incorrect secret key");
        }
    } catch (error) {
        console.error("Error finding user:", error);
        res.status(500).send("Internal Server Error");
    }
});
app.post('/password', async (req, res) => {
    const { username, resetpass } = req.body;
    if (req.body.resetpass !== req.body.pcpass) {
        const alertScript = `
            <script>
                alert("Password and Confirm Password do not match");
                window.location.href = "/password.html";
            </script>
        `;
        return res.send(alertScript);
    }
        const specialCharacterRegex = /[!@#$%^&*(),.?":{}|<>]/;
          const capitalLetterRegex = /[A-Z]/;
             const numberRegex = /[0-9]/;
    if (!numberRegex.test(req.body.resetpass) || !specialCharacterRegex.test(req.body.resetpass) || !capitalLetterRegex.test(req.body.resetpass)) {
        const alertScript = `
            <script>
            alert("Password must contain at least one special character, one capital letter, and one number");
                window.location.href = "/password.html";
            </script>
        `;
        return res.send(alertScript);
    }
    try {
        const hashedpassword = await bcrypt.hash(resetpass, 10);
        const updatedUser = await modelcse.findOneAndUpdate({ user: username }, { pass: hashedpassword }, { new: true });
        console.log(updatedUser);
        if (!updatedUser) {
            return res.status(404).send("User not found");
        }
        const alertScript = `
        <script>
        alert("Password updated successfully...");
            window.location.href = "/login.html";
        </script>
    `;
    return res.send(alertScript);
    } catch (error) {
        console.error("Error updating password:", error);
        res.status(500).send("Internal Server Error");
    }
});
app.post('/update', async (req, res) => {
       let data = {
            recipe: req.body.rep,
            ingredients: req.body.ingredients,
            description: req.body.description,
            category: req.body.category,
            recipetype: req.body.type
        };

        let newRecipe;
        if (data.category === 'veg') {
            const existingvegRecipe = await VegRecipe.findOne({ recipe: data.recipe });
            if (existingvegRecipe) {
                return res.send('<script>alert("Recipe already exists!"); window.location.href = "/updaterecipe";</script>');
            }
            newRecipe = new VegRecipe(data);
        } else if (data.category === 'nonveg') {
            const existingnonegRecipe = await NonVegRecipe.findOne({ recipe: data.recipe });
            if (existingnonegRecipe) {
                return res.send('<script>alert("Recipe already exists!"); window.location.href = "/updaterecipe";</script>');
            }
            newRecipe = new NonVegRecipe(data);
        } else {
            return res.status(400).send('Invalid category');
        }

        await newRecipe.save();

        let pic = req.files.file;
        let uploadPath = __dirname + '/public/images/' + pic.name;
        pic.mv(uploadPath, err => {
            if (err) {
                console.error(err);
                return res.status(500).send(err);
            }
            fs.rename(uploadPath, __dirname + '/public/images/' + req.body.rep + '.jpg', error => {
                if (error) {
                    console.error(error);
                }
            });
        });
        res.redirect('/success');
});
app.get('/updaterecipe',(req,res)=>{
    res.sendFile(__dirname+'/public/updaterecipe.html')
})
app.get('/success', (req, res) => {
    req.session.alertShown = true;
    res.send('<script>alert("THANKS FOR SHARING THE RECIPE!"); window.location.href = "/home1";</script>');
});

app.get('/home1', (req, res) => {
    if (!req.session.alertShown) {
        res.send('<script>alert("THANKS FOR SHARING THE RECIPE!"); window.location.href = "/home";</script>');
    } else {
        res.sendFile(__dirname + '/public/home.html');
    }
});
